import React from 'react';

const Home: React.FC = () => {
  return <div>Главная страница</div>;
};

export default Home;