import React from 'react';

const RouteBuilder: React.FC = () => {
  return <div>Построение маршрута</div>;
};

export default RouteBuilder;