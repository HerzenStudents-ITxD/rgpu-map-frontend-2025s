// src/features/3dMap/components/Building.tsx
import { useGLTF } from '@react-three/drei';
import type { GLTF } from 'three-stdlib';
import { useNavigate } from 'react-router-dom';
import { MapPoint3D } from '../api/mockPoints';

interface BuildingProps {
  building: MapPoint3D;
}

export const Model = ({ building }: BuildingProps) => {
  const navigate = useNavigate();
  const { scene } = useGLTF(building.model) as GLTF;
  
  const handleClick = () => {
    if (building.metadata.isInteractive) {
      navigate(building.metadata.url);
    }
  };

  return (
    <primitive 
      object={scene} 
      position={building.position}
      onClick={handleClick}
      userData={{ interactive: building.metadata.isInteractive }}
    />
  );
};