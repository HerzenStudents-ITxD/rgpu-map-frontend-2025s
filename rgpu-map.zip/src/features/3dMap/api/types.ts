// src/features/3dMap/api/types.ts
export interface Building {
    id: string;
    name: string;
    model: string;
    position: [number, number, number];
    rotation?: [number, number, number];
    metadata?: {
      floors?: number;
      isInteractive?: boolean;
    };
  }
  
  export interface MapState {
    buildings: Building[];
    selectedBuilding: string | null;
  }
  
  export interface MapActions {
    selectBuilding: (id: string | null) => void;
    addBuilding: (building: Building) => void;
  }

  export type BuildingClickHandler = (buildingId: string) => void;

  // src/features/3dMap/api/types.ts
  
export interface MapPoint3D {
  id: number; // Меняем на number
  name: string;
  position: [number, number, number];
  rotation?: [number, number, number];
  model: string;
  metadata: {
    floors?: number;
    isInteractive: boolean;
    url: string; // Добавляем поле для URL
  };
}

// src/features/3dMap/api/mockBuildings.ts
export const mockBuildings: MapPoint3D[] = [
  {
    id: 1,
    name: 'Главный корпус',
    position: [0, 0, 0],
    model: '/models/main-campus.glb',
    metadata: {
      floors: 5,
      isInteractive: true,
      url: '/point/1' // Формируем URL на основе ID
    }
  },
  {
    id: 2,
    name: 'Библиотека',
    position: [15, 0, 8],
    model: '/models/library.glb',
    metadata: {
      isInteractive: true,
      url: '/point/2'
    }
  }
];